
appcfg.ini

包含了测试脚本的各种环境的配置，终端号商户号服务器地址端口等等


packageDefGrp.Def

报文定义注册文件


seq.txt

记录流水号的文件


term8583.Def

终端8583报文定义文件



